# Technoshop
## Client

Ограниченный клиент для проверки базы данных


## License
MIT

